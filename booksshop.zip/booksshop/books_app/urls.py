from django.conf.urls.static import static
from django.urls import path,include


from .views import books_list,books_detail
urlpatterns=[
    path("all/",books_list, name="all_books_list"),
    path("<int:id>/",books_detail,name="books_detail_page"),

]